$(document).ready(function () {
    "use strict";
        // Animate loader off screen
        $( ' .preloader' ).fadeOut("slow");
        setTimeout(function(){ $('.preloader').fadeOut('slow'); }, 3000);
    });

/* serach */
function openSearch() {
    $('body').addClass("active-search");
    document.getElementById("search-toggle").style.height = "auto";
    $('#search-toggle').addClass("dblock");
    $('.search_query').attr('autofocus', 'autofocus').focus();
}
function closeSearch() {
    $('body').removeClass("active-search");
    document.getElementById("search-toggle").style.height = "0";
    $('#search-toggle').addClass("dnone");
    $('.search_query').attr('autofocus', 'autofocus').focus();
}

// Feature Product section carousel
$('#feature_product').owlCarousel({
  loop: true,  
  pagination:false,
  navigation:false,
  nav: true,
  dots:false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: false,
  responsive: {
    320: {
      items: 2
    },
    400: {
      items: 2
    },
    576: {
      items: 3
    },
    992: {
      items: 4
    },
    1200: {
      items: 4
    },
    1410: {
      items: 4
    },
    1850: {
      items: 4
    }
  }
})

// Customer Review Section
// carousel
$('#customer_review').owlCarousel({
  loop: true,  
  pagination:false,
  navigation:false,
  nav: true,
  dots:false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: false,
  responsive: {
    0: {
      items: 1
    },
    576: {
      items: 1
    },
    992: {
      items: 1
    },
    1200: {
      items: 1
    },
    1410: {
      items: 1
    },
    1850: {
      items: 1
    }
  }
})
// Latest product Section Carousel
$('#latest_product').owlCarousel({
  loop: true,  
  pagination:false,
  navigation:false,
  nav: true,
  dots:false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: false,
  responsive: {
    320: {
      items: 2
    },
    400: {
      items: 2
    },
    576: {
      items: 3
    },
    992: {
      items: 4
    },
    1200: {
      items: 4
    },
    1410: {
      items: 4
    },
    1850: {
      items: 4
    }
  }
})
// Latest news Section carousel
$('#latest_news').owlCarousel({
  loop: true,  
  pagination:false,
  navigation:false,
  nav:true,
  dots:false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: false,
  autoplayHoverPause: false,
  responsive: {
    0: {
      items: 1
    },
    576: {
      items: 2
    },
    992: {
      items: 3
    },
    1200: {
      items: 3
    },
    1410: {
      items: 3
    },
    1850: {
      items: 3
    }
  }
})
// Brand partners casousel
$('#brand_icon').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    dots:false,
    autoplay:true,
    autoplayTimeout:3000,
    responsive: {
    0: {
      items: 2
    },
    400: {
      items: 3
    },
    576: {
      items: 3
    },
    600: {
      items: 3
    },
    767: {
      items: 3
    },
    992: {
      items: 4
    },
    1200: {
      items: 5
    },
    1410: {
      items: 5
    },
    1850: {
      items: 6
    }
  }
})

//Testimonials in about us page

$('#testimonials').owlCarousel({
  loop: true,  
  pagination:false,
  navigation:false,
  dots:false,
  nav: true,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 1
    },
    425: {
      items: 1
    },
    576: {
      items: 1
    },
    991: {
      items: 2
    },
    1200: {
      items: 2
    },
    1410: {
      items: 2
    },
    1850: {
      items: 2
    }
  }
})

//our team in about us page

$('#our_team').owlCarousel({
  loop: true,  
  pagination:false,
  navigation:false,
  dot:false,
  nav:false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 2
    },
    425: {
      items: 2
    },
    576: {
      items: 3
    },
    991: {
      items: 4
    },
    1200: {
      items: 4
    },
    1410: {
      items: 5
    },
    1850: {
      items: 5
    }
  }
})
// related Product section carousel
$('#related_product').owlCarousel({
  loop: true,  
  pagination:false,
  navigation:false,
  nav: true,
  dots:false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: false,
  responsive: {
    320: {
      items: 2
    },
    400: {
      items: 2
    },
    576: {
      items: 3
    },
    992: {
      items: 4
    },
    1200: {
      items: 4
    },
    1410: {
      items: 4
    },
    1850: {
      items: 4
    }
  }
})
// custom Product section carousel
$('#custom_product').owlCarousel({
  loop: true,  
  pagination:false,
  navigation:false,
  nav: true,
  dots:false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: false,
  responsive: {
    320: {
      items: 2
    },
    400: {
      items: 2
    },
    576: {
      items: 3
    },
    992: {
      items: 4
    },
    1200: {
      items: 4
    },
    1410: {
      items: 4
    },
    1850: {
      items: 4
    }
  }
})
// single product page 

$('#gallery_02').owlCarousel({
  loop: true,  
  pagination:true,
  navigation:true,
  nav: true,
  dots: false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 3
    },
    425: {
      items: 3
    },
    576: {
      items: 4
    },
    991: {
      items: 4
    },
    1200: {
      items: 4
    },
    1410: {
      items: 5
    },
    1850: {
      items: 5
    }
  }
})




// Search Icon js
function searchToggle(obj, evt){
    var container = $(obj).closest('.search-wrapper');
        if(!container.hasClass('active')){
            container.addClass('active');
            evt.preventDefault();
        }
        else if(container.hasClass('active') && $(obj).closest('.input-holder').length == 0){
            container.removeClass('active');
            // clear input
            container.find('.search-input').val('');
        }
}

/* responsive menu */
function openNav() {
    $('body').addClass("active");
    document.getElementById("mySidenav").style.width = "280px";
}
function closeNav() {
    $('body').removeClass("active");
    document.getElementById("mySidenav").style.width = "0";
}
/* responsive menu */

//cart product remove
      $( document ).ready(function(){

  $( ".cart_cross" ).click(function() {
    $(this).fadeOut( "slow", function() {
      // After animation completed:
      $(this).remove();
    });
    $( this ).fadeOut( "slow", function() {
      // After animation completed:
      $( this ).remove();
    });
  });

      $( ".wblastcart" ).click(function() {
          $(this).parent().remove();
      });

 });
//plus minus quantity
$(document).ready(function() {
      $('.minus').click(function () {
        var $input = $(this).parent().find('input');
        var count = parseInt($input.val()) - 1;
        count = count < 1 ? 1 : count;
        $input.val(count);
        $input.change();
        return false;
      });
      $('.plus').click(function () {
        var $input = $(this).parent().find('input');
        $input.val(parseInt($input.val()) + 1);
        $input.change();
        return false;
      });
    });


//scroll
$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('#myBtn').fadeIn();
        } else {
            $('#myBtn').fadeOut();
        }
    });
    $('#myBtn').click(function () {
        $("html, body").animate({scrollTop: 0}, 600);
        return false;
    });
});
//scroll



// alert js
      function alertFunction() {
        alert("Sorry! You Must Log in First For Access This Action");
      }

// appand for navbar

$(document).ready(function () {
if($(window).width() < 1200) {
          
      $(".res_ap").appendTo(".appandd_new");
        }

  });
 
// curruncy appand
if($(window).width() < 992) {
   $( ".curruncy" ).appendTo( ".r_menu" );

    $('#wbcurr').click(function(event){
    $(this).toggleClass('active');
    event.stopPropagation();
    $(".head_").slideToggle("fast");
    return false;
  });
}

// language appand
if($(window).width() < 992) {
   $( ".language" ).appendTo( ".r_menu" );

    $('#wblang').click(function(event){
    $(this).toggleClass('active');
    event.stopPropagation();
    $(".headd_").slideToggle("fast");
    return false;
  });
}

// appand for blog-left-sidebar

$(document).ready(function () {
if($(window).width() < 768) {
          
      $(".left-side-recent").appendTo(".left-side");
        }

  });

// left shop page

$(document).ready(function() {
      $('#list').click(function(event){event.preventDefault();$('#products .item').addClass('shop_list_item');});
      $('#grid').click(function(event){event.preventDefault();$('#products .item').removeClass('shop_list_item');$('#products .item').addClass('shop_grid_item');});
});

// appand for shop-right-sidebar

$(document).ready(function () {
if($(window).width() < 768) {
          
      $(".left-side-recent").appendTo(".left-side");
        }

  });

$(window).scroll(function() {
    if ($(window).scrollTop() > 10) {
        $('#sticky').addClass('floatingNav');
    } else {
        $('#sticky').removeClass('floatingNav');
    }
});






