


$(document).ready(function() {
    $('.select').niceSelect();
});